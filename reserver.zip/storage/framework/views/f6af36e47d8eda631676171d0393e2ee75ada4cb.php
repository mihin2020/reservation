<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>send-mail</title>
    <link rel="stylesheet" href="/css/dashboard.css">
    <link rel="stylesheet" href="/css/bootstrap.min.css">
</head>
<body>
    <div class="card">
  <div class="card-header">
  Bienvenue sur la plateforme de reservation
  </div>
  <div class="card-body">
    <h5 class="card-title">Mail de verification</h5>
    <p class="card-text">Hello!!nous vous convions à bien vouloir cliquer sur le boutton ci dessous pour valider votre inscription</p>
    <a href="/connexion" class="btn btn-primary">valider</a>
  </div>
</div>
</body>
</html>
<?php /**PATH C:\laragon\www\reserver\resources\views//email/register.blade.php ENDPATH**/ ?>