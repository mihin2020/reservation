<h1>

bienvenue cher ami
</h1><?php /**PATH C:\laragon\www\reserver\resources\views/email/register.blade.php ENDPATH**/ ?>