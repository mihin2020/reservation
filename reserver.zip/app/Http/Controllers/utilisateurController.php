<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class utilisateurController extends Controller
{
    public function utilisateur(){
        
    }
}
